import java.util.Scanner;

class Main extends Atm{
    static Scanner scan = new Scanner(System.in); 
    static boolean loop = true;
    public static void ulangi(){
        System.out.print("Ketik 1 untuk kembali dan 2 untuk mengulangi! ");
        int ulangi = scan.nextInt();
        System.out.println("\n");
        scan.nextLine();
        if (ulangi == 1) {
            loop = false;
        } else if (ulangi == 2) {
            loop = true;
        } else {
            System.out.println("Masukkan salah.");
        }
    }
    public static void main(String[] args) {
        Bank atm = new Atm();
        atm.login();
        atm.cekArraylist();
        while (true) {
            System.out.println("====== MENU =======\n1. Informasi Rekening\n2. Transfer\n3. Mutasi\n4. Penarikan\n5. Logout");
            System.out.print("Masukkan Pilihan Anda = ");
            int pilih = scan.nextInt();
            loop = true;
            switch (pilih) {
                case 1:
                    while(loop){
                        atm.infoRek();                  
                        ulangi();
                    }
                    break;
                case 2:
                    while(loop){
                        System.out.print("Rekening tujuan : ");
                        int rekT = scan.nextInt();
                        System.out.print("Jumlah : ");
                        int jml = scan.nextInt();
                        atm.transaksi(rekT, jml);
                        ulangi();
                    }
                    break;
                case 3:
                    while(loop){
                        atm.mutasi();
                        ulangi();
                    }
                    break;
                case 4:
                    while(loop){
                        atm.tarik();
                        ulangi();
                    }
                break;
                case 5:
                    System.exit(0);
                    break;
                default :
                    System.out.println("Pilihan Anda Tidak Tepat");
                    break;
            }    
        }
    }    
}