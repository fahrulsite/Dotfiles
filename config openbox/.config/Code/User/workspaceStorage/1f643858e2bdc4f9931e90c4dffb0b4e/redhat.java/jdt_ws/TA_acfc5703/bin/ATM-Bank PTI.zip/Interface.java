import java.util.Date;

public interface Interface {
    public Date date = new Date();

    public final int kartu = 56789;
    public final int pin = 1234;
    public void login();
}