public abstract class Bank extends Filee implements Interface{
   public void infoRek(){
        System.out.println("===== Info Rekening =====");
        System.out.println("No Kartu : " + kartu);
        System.out.println("Saldo: " + cekSaldo());
   }
   
   public abstract void transaksi(int rekTujuan, int jumlah);
   public abstract void mutasi();
   public abstract int tarik();
}