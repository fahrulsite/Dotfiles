import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Filee {
    public static ArrayList<Integer> mutasi = new ArrayList<Integer>();
    public static ArrayList<String> tanggal = new ArrayList<String>();
    
    public static String fileSaldo = "saldo.txt" ; 
    public static String fileMutasi = "mutasi.txt";
    public static String fileTanggal = "tanggal.txt";
    public static int saldo;
    public static void cekArraylist(){
        if(mutasi.isEmpty() && tanggal.isEmpty()){
            try {
                File mutasiFile = new File(fileMutasi);
                Scanner readerMutasi = new Scanner(mutasiFile);
                String newMutasi = readerMutasi.nextLine();
                newMutasi = newMutasi.substring(1);
                newMutasi = newMutasi.substring(0, newMutasi.length() - 1);
                newMutasi = newMutasi.replaceAll(" ","");

                for (String mut : newMutasi.split(",")) { 
                    Integer i = Integer.valueOf(mut);
                    mutasi.add(i);
                }

                File tanggalFile = new File(fileTanggal);
                Scanner readerTanggal = new Scanner(tanggalFile);
                String newTanggal = readerTanggal.nextLine();
                newTanggal = newTanggal.substring(1);
                newTanggal = newTanggal.substring(0, newTanggal.length() - 1);
                tanggal = new ArrayList<>(Arrays.asList(newTanggal.split(",")));
            } catch (FileNotFoundException e) {
                System.out.println("error");
            } catch(NoSuchElementException e){
                
            }
        }
    }
    public static int cekSaldo(){
        try {
            // membaca file
            File myFile = new File(fileSaldo);
            Scanner fileReader = new Scanner(myFile);
            saldo = fileReader.nextInt();
            
        } catch (FileNotFoundException e) {
            System.out.println("Terjadi Kesalahan: " + e.getMessage());
            e.printStackTrace();
        }
        return saldo;
    }

    
}