import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Atm extends Bank {
    Random random = new Random();
    Scanner scan = new Scanner(System.in);
    public void transaksi(int paramRekeningTujuan, int paramJumlah) {
        if(paramJumlah>saldo){
            System.out.println("Maaf, sisa saldo anda tidak mencukupi");
        }else{
            // boolean ulanglagi = true;
            int angka = random.nextInt(6);
            
                int validasi = faktorial(angka);
                System.out.println(angka+"!");
                System.out.print("Ketikkan hasil faktorial diatas sebagai bukti bahwa anda bukan robot : ");
                int hasil = scan.nextInt();
                if (hasil==validasi) {
                    kurangiSaldo(paramJumlah);
                    System.out.println("Sisa saldo : "+saldo);    
                }else{
                    System.out.println("Error! Jawaban Anda salah");
                }    
        }
    }

    public int faktorial(int n){
        if(n==0){
            return 1;
        }else{
            return n* faktorial(n-1);
        }
    }

    public void mutasi() {
        System.out.println("===== Mutasi =====");
        if(mutasi.isEmpty()){
            System.out.println("Anda belum pernah melakukan transaksi");
        }else{
            System.out.println("Tanggal\t\t\t\t Jumlah Transaksi");
            for (int i = mutasi.size()-1; i >=0 ; i--) {
                System.out.print(tanggal.get(i)+"\t");
                System.out.println("Rp"+mutasi.get(i));
            }
        }
    }

    public void login(){
        boolean ulang = true;
        while(ulang){
            try {
                System.out.println("======= Bank PTI =======");
                System.out.print("Masukkan Nomer Kartu : ");
                int inputKartu = scan.nextInt();
                scan.nextLine();
            
                System.out.print("Masukkan PIN : ");
                int inputPIN = scan.nextInt();
                if (inputKartu != kartu) {
                    System.out.println("Nomer kartu salah");
               } else if(inputPIN != pin){
                   System.out.println("PIN salah");
               } else{
                   ulang = false;
               }
            } catch (InputMismatchException e) {
                System.out.println("Nomer Kartu dan PIN harus angka");
                System.exit(0);
            }       
        }
    }

    public int tarik(){
        int i = 0;
        int penarikan;

        do{
        System.out.print("Masukan nominal penarikan    : ");
        penarikan = scan.nextInt();
        if (penarikan > saldo){
            System.out.println("Maaf, saldo Anda tidak mencukupi");
            System.out.println("silahkan masukan nominal yang lebih kecil");
        }else if (penarikan < 0){
            System.out.println("Maaf Anda tidak memasukkan nominal yang benar");
            System.out.println("Silahkan masukkan nominal yang benar");
            tarik();
        }
        else {
            System.out.println("penarikan berhasil, sebanyak : " +penarikan);
            System.out.println("terima kasih^^, silahkan ambil uang anda ...");
            kurangiSaldo(penarikan);
        }
        i++;
        }
        while ( penarikan > saldo);
        return saldo;
        }

    public static void kurangiSaldo(int paramSaldo){
        try {
            tanggal.add(date.toString());
            mutasi.add(paramSaldo);
            saldo = saldo - paramSaldo;
            String textSaldo = Integer.toString(saldo);
            FileWriter fileWriter = new FileWriter(fileSaldo);
            fileWriter.write(textSaldo);
            fileWriter.close();

            FileWriter writerTanggal = new FileWriter(fileTanggal);
            String listTanggal =tanggal.toString();
            writerTanggal.write(listTanggal);
            writerTanggal.close();

            FileWriter writerMutasi = new FileWriter(fileMutasi);
            String listMutasi =mutasi.toString();
            writerMutasi.write(listMutasi);
            writerMutasi.close();
        } catch (IOException e) {
            System.out.println("Terjadi kesalahan karena: " + e.getMessage());
        }
    }
}